import './App.css';
import React from 'react';
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import Layout from './comps/Layout';
import Home from './comps/Home';
import About from './comps/About';
import Redirect from '.comps/Redirect';
const Blog = React.lazy( ()=>import('./comps/Blog'));
//import Blog from './comps/Blog';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
            <Route index element={<Redirect path="/home" />} />
            <Route path="/home" element={<Home />}/>
            <Route path="/about" element={<About />}/>
            <Route path="/blog" element={<Blog />}/>
        </Route>
      </Routes>
    </Router>
  );
}

export default App;
